﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace Selenium_dotNet_Project
{
    /// <summary>
    /// Summary description for UnitTest
    /// </summary>
    [TestClass]
    public class Case_Study_1
    {
        [TestMethod]
        public void Case_Study()
        {
            String vURL = "https://www.google.com";
            String vSearch = "DXC Technologies";
            IWebDriver driver;
            driver = new ChromeDriver("C:\\Selenium Jar");
            driver.Url = vURL ;
            Thread.Sleep(4000);
            driver.FindElement(By.Name("q")).SendKeys(vSearch); //Send the vSearch URL to the Google Search Bar
            Thread.Sleep(2000);
            driver.FindElement(By.ClassName("gNO89b")).Click(); //Clicks the Search Button
            String Page_Title = driver.Title; // Extracts Page Title
            Console.WriteLine("Page Title: " + Page_Title); //Prints Page Title
            String Result_Stat = driver.FindElement(By.XPath("/html/body/div[7]/div[3]/div[7]/div[1]/div/div/div/div")).Text; // Extracts Result Statistics
            Console.WriteLine("Result Statistics: " + Result_Stat); //Prints Result Statistics

            if(Page_Title.Contains(vSearch))
            {
                Console.WriteLine("Test Case Passed");
            }
            else
            {
                Console.WriteLine("Test Case Failed");
            }
            Thread.Sleep(2000);
            driver.Close();
            
        }
    }
}
