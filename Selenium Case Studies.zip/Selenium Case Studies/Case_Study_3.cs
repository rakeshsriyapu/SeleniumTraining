﻿using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Interactions;

namespace Selenium_dotNet_Project
{
    [TestClass]
    public class Case_Study_3
    {
        [TestMethod]
        public void CaseStudy3()
        {
            String vURL = "http://www.youcandealwithit.com/";
            IWebDriver driver = new FirefoxDriver("C:\\Selenium Jar");

            driver.Manage().Window.Maximize();
            driver.Url = vURL;
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            Thread.Sleep(2000);
            Actions action = new Actions(driver);
            action.MoveToElement(driver.FindElement(By.XPath("/html/body/div[1]/ul[2]/li[1]/a"))).Build().Perform();
            driver.FindElement(By.LinkText("Calculators & Resources")).Click();
            Thread.Sleep(2000);
            String LT_CR = driver.FindElement(By.LinkText("Calculators & Resources")).Text;

            if (driver.Title.Contains(LT_CR))
            {
                driver.FindElement(By.LinkText("Calculators")).Click();
                Thread.Sleep(2000);
                String LT_C = driver.FindElement(By.LinkText("Calculators")).Text;
                Console.WriteLine("Test Case: Budget Calculator & Resources Passed");
                if (driver.Title.Contains(LT_C))
                {
                    driver.FindElement(By.LinkText("Budget Calculator")).Click();
                    Thread.Sleep(2000);
                    String LT_BC = driver.FindElement(By.LinkText("Budget Calculator")).Text;
                    Console.WriteLine("Test Case: Calculator Passed");
                    if (driver.Title.Contains(LT_BC))
                    {
                        driver.FindElement(By.Id("food")).SendKeys("1000");
                        driver.FindElement(By.Id("clothing")).SendKeys("1500");
                        driver.FindElement(By.Id("shelter")).SendKeys("4000");
                        driver.FindElement(By.Id("monthlyPay")).SendKeys("30000");
                        driver.FindElement(By.Id("monthlyOther")).SendKeys("5000");
                        double Under_Over = Double.Parse(driver.FindElement(By.Id("underOverBudget")).GetAttribute("value"));
                        double Monthly_Expense = Double.Parse(driver.FindElement(By.Id("totalMonthlyExpenses")).GetAttribute("value"));
                        double Monthly_Pay = Double.Parse(driver.FindElement(By.Id("monthlyPay")).GetAttribute("value"));
                        Console.WriteLine("Under/Over Budget: " + Under_Over);

                        if (Monthly_Expense >= Monthly_Pay)
                        {
                            Console.WriteLine("You are Warren Buffet");
                        }
                        else
                        {
                            Console.WriteLine("You are VM");
                        }

                        Console.WriteLine("Test Case: Budget Calculator Passed");
                        driver.Close();
                    }
                    else
                    {
                        Console.WriteLine("Test Case Failed at Budget Calculator Link");
                    }

                }
                else
                {
                    Console.WriteLine("Test Case Failed at Calculators Link");
                }
            }
            else
            {
                Console.WriteLine("Test Case Failed at Calculators & Resources Link");
            }
        }
    }
}



